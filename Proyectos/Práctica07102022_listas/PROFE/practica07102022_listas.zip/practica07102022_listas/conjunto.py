clientes={"marta","luis","marta"}
print(clientes)
#set con {}. no soporta duplicados al mostrarlo. unordered

clientes.add("jorge")
print(clientes)