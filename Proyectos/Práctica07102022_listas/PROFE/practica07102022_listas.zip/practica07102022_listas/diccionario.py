precios={"camisa":9.95,"pantalón":25.95}
print(precios)
print(precios["pantalón"])